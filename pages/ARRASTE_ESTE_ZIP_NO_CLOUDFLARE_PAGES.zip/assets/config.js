window.CLTECH_CONFIG = {
  SUPABASE_URL: "https://ihommfxxdynexzzshwhi.supabase.co",
  SUPABASE_PUBLISHABLE_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlob21tZnh4ZHluZXh6enNod2hpIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE5MDE0MjcsImV4cCI6MjA5NzQ3NzQyN30.goeQaDXX6BD4CkZ3UT-64BZqyhwp-x1vJRsTTeCCN30",
  WORKER_API_URL: localStorage.getItem("cltech_worker_url") || "",
  BRAND_NAME: "CLTECH Studio",
  OWNER_WHATSAPP: "5511951289502"
};
